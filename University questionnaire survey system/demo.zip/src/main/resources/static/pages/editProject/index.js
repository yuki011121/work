// let project = {}
//
// onload = () => {
//   $('#headerUsername').text($util.getItem('userInfo').username)
//   $('#headerDivB').text('编辑项目')
//
//   project = $util.getPageParam('editProject')
//
//   $('#projectName').val(project.projectName)
//   $('#projectDescribe').val(project.projectContent)
// }
//
// const handleSaveChange = () => {
//   console.log(project)
//   let params = {
//     id: project.id,
//     userId:project.userId,
//     createdBy:project.createdBy,
//     projectName: $('#projectName').val(),
//     projectContent: $('#projectDescribe').val()
//   }
//   console.log(params)
//   if (!params.projectName) return alert('项目名称不能为空！')
//   if (!params.projectContent) return alert('项目描述不能为空！')
//   $.ajax({
//     url: API_BASE_URL + '/admin/modifyProjectInfo',
//     type: "POST",
//     data: JSON.stringify(params),
//     dataType: "json",
//     contentType: "application/json",
//     success(res) {
//       alert(res.message)
//       location.href = "/pages/questionnaire/index.html"
//     }
//   })
// }
let project = {}

onload = () => {
  $('#headerUsername').text($util.getItem('userInfo')[0].username)
  $('#headerDivB').text('编辑项目')

  project = $util.getPageParam('editProject')

  $('#projectName').val(project.projectName)
  $('#projectDescribe').val(project.projectContent)
}

const handleSaveChange = () => {
  let params = {
    id: project.id,
    projectName: $('#projectName').val(),
    projectContent: $('#projectDescribe').val()
  }
  if (!params.projectName) return alert('项目名称不能为空！')
  if (!params.projectContent) return alert('项目描述不能为空！')
  $.ajax({
    url: API_BASE_URL + '/admin/modifyProjectInfo',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res) {
//      alert(res.message)
      location.href = "/pages/questionnaire/index.html"
    }
  })
}


// let project = {}
//
// onload = () => {
//   $('#headerUsername').text($util.getItem('userInfo').username)
//   $('#headerDivB').text('编辑项目')
//
//   project = $util.getPageParam('editProject')
//
//   $('#projectName').val(project.projectName)
//   $('#projectDescribe').val(project.projectContent)
// }
//
// const handleSaveChange = () => {
//   console.log(project)
//   let params = {
//     id: project.id,
//     userId:project.userId,
//     createdBy:project.createdBy,
//     projectName: $('#projectName').val(),
//     projectContent: $('#projectDescribe').val()
//   }
//   console.log(params)
//   if (!params.projectName) return alert('项目名称不能为空！')
//   if (!params.projectContent) return alert('项目描述不能为空！')
//   // console.log(params)
//   // alert(JSON.stringify(params))
//   $.ajax({
//     url: API_BASE_URL + '/admin2/modifyProjectInfo',
//     type: "POST",
//     data: JSON.stringify(params),
//     dataType: "json",
//     contentType: "application/json",
//     success(res) {
//       alert(res.message)
//       location.href = "/pages/questionnaire/index.html"
//     }
//   })
// }
