function getQueryVariable(variable)
{
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i=0;i<vars.length;i++) {
        var pair = vars[i].split("=");
        if(pair[0] == variable){return pair[1];}
    }
    return(false);
}

onload = () => {
    var questionnaireId = getQueryVariable("questionnaireId")
    console.log(questionnaireId)

    var params = {
        id: questionnaireId
    }
    $.ajax({
        url: API_BASE_URL + '/admin/queryQuestionnaireById',
        type: "POST",
        data: JSON.stringify(params),
        dataType: "json",
        contentType: "application/json",
        success(res) {
            console.log(res)
            if (res.data.state == 'close') {
                alert('问卷未发布')
//                window.location.href = ''
            }
            $('.questionnaire-title').text(res.data.questionnaireName)
            $('.questionnaire-description').text(res.data.questionnaireContent)
        }
    })
    params = {
        questionnaireId: questionnaireId
    }
    $.ajax({
        url: API_BASE_URL + '/admin/queryQuestionByQuestionnaireId',
        type: "POST",
        data: JSON.stringify(params),
        dataType: "json",
        contentType: "application/json",
        async: false,
        success(res) {
            console.log(res)
            for (var i = 0; i < res.data.length; i++) {
                $('#problem').append(`
                    <div class="question" data-type=${res.data[i].type} data-problemIndex=${i+1}>
                    <div class="top">
                        <span class="question-title" id="questionTitle">${res.data[i].questionContent}</span>
                `)
                if (res.data[i].mustAnswer == "true"){
                    $('#problem').append(`
                        <span class="must-answer">必答题</span>
                    `)
                }
                $('#problem').append(`
                    </div>
                `)
                params = {
                    questionId: res.data[i].id
                }
                $.ajax({
                    url: API_BASE_URL + '/admin/queryItemByQuestionId',
                    type: "POST",
                    data: JSON.stringify(params),
                    dataType: "json",
                    contentType: "application/json",
                    async: false,
                    success(ans) {
                        console.log(ans)
                        $('#problem').append(`
                            <div class="bottom">
                        `)
                        if (res.data[i].type == 1) {
                            var all = 0;
                            for (var j = 0; j < ans.data.length; j++){
                                all += ans.data[j].itemCount;
                            }
                            for (var j = 0; j < ans.data.length; j++) {
                                $('#problem').append(`
                                    <div style="display: flex; align-items: center; margin-bottom: 3px;">
                                    <label class="radio-inline">
                                    ${ans.data[j].itemContent} 计数 ${ans.data[j].itemCount} 占比 ${ans.data[j].itemCount/all*100}%
                                    </label>
                                    </div>
                                `)
                            }
                            $('#problem').append(`
                                </div>
                            `)
                        }
                        else if (res.data[i].type == 2) {
                            var all = 0;
                            for (var j = 0; j < ans.data.length; j++){
                                all += ans.data[j].itemCount;
                            }
                            for (var j = 0; j < ans.data.length; j++) {
                                $('#problem').append(`
                                    <div style="display: flex; align-items: center; margin-bottom: 3px;">
                                    <label class="checkbox-inline">
                                    ${ans.data[j].itemContent} 计数 ${ans.data[j].itemCount} 占比 ${ans.data[j].itemCount/all*100}%
                                    </label>
                                    </div>
                                `)
                            }
                            $('#problem').append(`
                                </div>
                            `)
                        }
                        else if (res.data[i].type == 3) {
                            $('#problem').append(`
                                <textarea class="form-control" placeholder="请输入" rows="4" style="width: 70%;"></textarea>
                                </div>
                            `)
                        }
                        else if (res.data[i].type == 4) {  //矩阵
                            let str="";
                            var titles = res.data[i].title.split(',')
                            str += `
                                    <table class="table">
                                      <thead>
                                       <tr>
                                        <th></th>
                                         `
                            var l = res.data[i].title.split(',').length
                            console.log(l, 'l')
                            for (var j = 0; j < ans.data.length/l; j++) {
                                str += `
                                            <th>${ans.data[j].itemContent}</th>
                                        `
                            }
                            str += `
                                        </tr>
                                        </thead>
                                        <tbody>
                                        `
                            for (var j = 0; j < titles.length; j++) {
                                var all = 0
                                for (var k = 0; k < ans.data.length/l; k++) {
                                    all += ans.data[j*ans.data.length/l+k].itemCount
                                }
                                str += `
                                    <tr>
                                        <td>${titles[j]}</td>
                                `
                                for (var k = 0; k < ans.data.length/l; k++) {
                                    str += `
                                        <td>计数 ${ans.data[j*ans.data.length/l+k].itemCount} 占比 ${ans.data[j*ans.data.length/l+k].itemCount/all*100}%</td>
                                    `
                                }
                                str += `
                                    </tr>
                                `
                            }
                            str += `
                                </tbody>
                                </table>
                                </div>
                            `
                            $('#problem').append(str)
                        }
                        else if (res.data[i].type == 5) {  //量表
                            var str = ''
                            titles = res.data[i].title.split(',')
                            str += `
                            <div class="bottom" style="display: flex; align-items: center; justify-content: space-between;">
                            `
                            str += `
                                <div> ${titles[0]}</div>
                                `
                            var all = 0
                            for (var j = 0; j < ans.data.length; j++) {
                                all += ans.data[j].itemCount
                            }
                            for (var j = 0; j < ans.data.length; j++) {
                                str += `
                                    <div>
                                      <label class="radio-inline">
                                        ${ans.data[j].itemContent}  计数 ${ans.data[j].itemCount} 占比 ${ans.data[j].itemCount/all*100}%
                                      </label>
                                    </div>
                                `
                            }
                            str += `
                                <div> ${titles[1]}</div>
                                </div>
                                `
                            $('#problem').append(str)
                        }
                    }
                })
                $('#problem').append(`
                    </div>
                `)
            }
        }
    })
}

const submit = () => {
    window.location.href = '../seeProject/index.html'
}
