package com.example.newdemo.service;

import com.example.newdemo.common.utils.UUIDUtil;
import com.example.newdemo.dao.ProjectEntityMapper;
import com.example.newdemo.dao.entity.ProjectEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Timestamp;
import java.util.List;

@Service
public class ProjectService {
    @Autowired
    private ProjectEntityMapper projectEntityMapper;


    /**
     * 查询项目列表
     */
    public List<ProjectEntity> queryProjectList(ProjectEntity projectEntity) {
        List<ProjectEntity> result = projectEntityMapper.queryProjectList(projectEntity);
        return result;
    }

    /**
     * 创建项目基本信息
     */
    public int addProjectInfo(ProjectEntity projectEntity) {
        projectEntity.setId(UUIDUtil.getOneUUID());
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        projectEntity.setCreationDate(timestamp);
        int result = projectEntityMapper.insert(projectEntity);
        if (result != 0) {
            return 3;   //3表示项目存在
        } else {
            return result;
        }
    }

    /**
     * 根据id删除项目信息
     */
    public int deleteProjectById(ProjectEntity projectEntity) {
        int result = projectEntityMapper.deleteProjectById(projectEntity);
        return result;
    }

    /**
     * 编辑项目信息
     */
    public int modifyProjectInfo(ProjectEntity projectEntity) {
        int result = projectEntityMapper.updateByPrimaryKeySelective(projectEntity);
        return result;
    }
}


//@Service
//public class ProjectService {
//    @Autowired
//    private ProjectEntityMapper projectEntityMapper;
//    /**
//     * 登录
//     */
//    public  List<ProjectEntity> selectProjectInfo(ProjectEntity projectEntity){
//        List<ProjectEntity> projectResult = projectEntityMapper.selectProjectInfo(projectEntity);
//        return projectResult;
//    }
//    /**
//     * 查询用户列表
//     */
//    public List<ProjectEntity> queryProjectList(ProjectEntity projectEntity){
//        List<ProjectEntity> result = projectEntityMapper.queryProjectList(projectEntity);
//        return result;
//    }
//
//    /**
//     * 根据项目名称查询
//     */
//    public List<ProjectEntity> queryProjectListByName(ProjectEntity projectEntity){
//        List<ProjectEntity> result = projectEntityMapper.queryProjectListByName(projectEntity);
//        return result;
//    }
//    /**
//     * 根据项目Id查询
//     */
//    public List<ProjectEntity> queryProjectListById(ProjectEntity projectEntity){
//        List<ProjectEntity> result = projectEntityMapper.queryProjectListById(projectEntity);
//        return result;
//    }
//    /**
//     * 创建项目
//     */
//    public int addProjectInfo(ProjectEntity projectEntity){
////        projectEntity.setId(UUIDUtil.getOneUUID());
//        int projectResult = projectEntityMapper.insert(projectEntity);
//        if( projectResult!=0){
//            return 3;//3代表项目存在
//        }
//        else{
//            return projectResult;
//        }
//
//    }
//
//    /**
//     * 修改项目信息
//     * @param projectEntity
//     * @return
//     */
//    public int modifyProjectInfo(ProjectEntity projectEntity){
//        int projectResult = projectEntityMapper.updateByPrimaryKey(projectEntity);
//        return projectResult;
//    }
//    /**
//     * 删除项目信息
//     */
//    public int deleteProjectById(ProjectEntity projectEntity){
//        int projectResult = projectEntityMapper.deleteProjectById(projectEntity);
//        return projectResult;
//    }
//}



