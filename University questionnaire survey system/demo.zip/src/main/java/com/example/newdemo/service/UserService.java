package com.example.newdemo.service;

import com.example.newdemo.common.utils.UUIDUtil;
import com.example.newdemo.dao.UserEntityMapper;
import com.example.newdemo.dao.entity.UserEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserService {
    @Autowired
    private UserEntityMapper userEntityMapper;

    /**
     * 查询用户
     */
    public List<UserEntity> selectUserInfo(UserEntity userEntity) {
        List<UserEntity> result = userEntityMapper.selectUserInfo(userEntity);
        return result;
    }

    /**
     * 查询用户列表
     */
    public List<UserEntity> queryUserList(UserEntity userEntity) {
        List<UserEntity> result = userEntityMapper.queryUserList(userEntity);
        return result;
    }

    /**
     * 创建用户基本信息
     */
    public int addUserinfo(UserEntity userEntity) {
        userEntity.setId(UUIDUtil.getOneUUID());
        int result = userEntityMapper.insert(userEntity);
        if (result != 0){
            return 3;   //3表示用户存在
        }
        else {
            return result;
        }
    }

    /**
     * 根据id删除用户信息
     */
    public int deleteUserByName(UserEntity userEntity) {
        int result = userEntityMapper.deleteUserByName(userEntity);
        return result;
    }

    /**
     * 编辑用户信息
     */
    public int modifyUserInfo(UserEntity userEntity) {
        int result = userEntityMapper.updateByPrimaryKeySelective(userEntity);
        return result;
    }
}
