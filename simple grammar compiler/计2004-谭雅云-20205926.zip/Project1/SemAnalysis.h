#pragma once
#include "sym.h"
#include "SYS.h"
using namespace std;
extern int err;
extern int q;
extern int offsetx;
void xieru(string m, typex ty);
int lookup(string m);
void outdaima(vector<struct quat>& qt);
void redefcheck(string m);
