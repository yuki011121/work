#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include <ctype.h>
#include "SYS.h"

extern SYS sys; 
extern string tem;
extern int error;
extern int id;
extern string nextchar;
extern string s;


void PZ();
void SF();
void ID();
void type();
void IT();
void SL();
void S();
void AS();
void AE();
void Z();
void T();
void F();
void CS();
void CE();
void LS();
void ZYZ();
int Synax();
