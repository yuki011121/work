function checkFunc() {
    var phone = document.getElementById("tel").value;
    var pwd1 = document.getElementById("pwd1").value;
    var pwd2 = document.getElementById("pwd2").value;
    
    if(pwd1!=pwd2){
    	alert("两次输入的密码不一致" + "\n请重新输入");
    }
    else if(!/^\d{7}(\d{1}(\d{3}(\d{1})?)?)?$/.test(phone)) {
    	alert("电话号码必须为数字且长度为 7,8,11或12位" + "\n请重新输入");
    }
    else 
    {
        document.getElementById("reg-data").submit();
    }
}
