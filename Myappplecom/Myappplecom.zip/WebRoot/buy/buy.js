window.onload = function() {
	var screensize = document.getElementsByName('screensize');
	var color = document.getElementsByName('color');
	var index="";
    for (var i = 0; i < screensize.length; i++) {
    	screensize[i].indexs = i + 2;
    	screensize[i].onchange = function () {
            if (this.checked) {
            	document.getElementById("image1").style.display="none";
                document.getElementById("image2").style.display="none";
                document.getElementById("image3").style.display="none";
                document.getElementById("image21").style.display="none";
                document.getElementById("image22").style.display="none";
                document.getElementById("image23").style.display="none";
                document.getElementById("image24").style.display="none";
                document.getElementById("image25").style.display="none";
                document.getElementById("image31").style.display="none";
                document.getElementById("image32").style.display="none";
                document.getElementById("image33").style.display="none";
                document.getElementById("image34").style.display="none";
                document.getElementById("image35").style.display="none";
                document.getElementById("image"+this.indexs+index).style.display="flex";
                if(this.indexs==2) {
                	for( var j = 0;j < color.length; j++){
                		color[j].indexs = j + 1;
                		color[j].onchange = function () {
                			if (this.checked) {
                            	document.getElementById("image1").style.display="none";
                                document.getElementById("image2").style.display="none";
                                document.getElementById("image3").style.display="none";
                                document.getElementById("image21").style.display="none";
                                document.getElementById("image22").style.display="none";
                                document.getElementById("image23").style.display="none";
                                document.getElementById("image24").style.display="none";
                                document.getElementById("image25").style.display="none";
                                document.getElementById("image31").style.display="none";
                                document.getElementById("image32").style.display="none";
                                document.getElementById("image33").style.display="none";
                                document.getElementById("image34").style.display="none";
                                document.getElementById("image35").style.display="none";
                				document.getElementById("image2" + this.indexs).style.display="flex";
                				index=this.indexs;
                			}
                 		}
                	}
                } else if(this.indexs==3) {
                	for( var j = 0;j < color.length; j++){
                		color[j].indexs = j + 1;
                		color[j].onchange = function () {
                			if (this.checked) {
                            	document.getElementById("image1").style.display="none";
                                document.getElementById("image2").style.display="none";
                                document.getElementById("image3").style.display="none";
                                document.getElementById("image21").style.display="none";
                                document.getElementById("image22").style.display="none";
                                document.getElementById("image23").style.display="none";
                                document.getElementById("image24").style.display="none";
                                document.getElementById("image25").style.display="none";
                                document.getElementById("image31").style.display="none";
                                document.getElementById("image32").style.display="none";
                                document.getElementById("image33").style.display="none";
                                document.getElementById("image34").style.display="none";
                                document.getElementById("image35").style.display="none";
                				document.getElementById("image3" + this.indexs).style.display="flex";
                				index=this.indexs;
                			}
                 		}
                	}
                }
            }
        }
    }
};

function nextInput(){
    var radios=document.getElementsByName("color");
    for(var i=0;i<radios.length;i++){
        radios[i].disabled=false;
    }
}