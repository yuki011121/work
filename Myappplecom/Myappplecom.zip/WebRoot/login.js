function checkForm(){
	var appleid = document.getElementById("AppleID").value;
    var password = document.getElementById("password").value;
if (appleid == null || appleid==""){
	alert("请输入Apple ID");
}
else if (password == null || password==""){
	alert("请输入密码");
}else {
	document.getElementById("login-form").submit();
}
}

