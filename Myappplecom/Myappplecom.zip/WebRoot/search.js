function searchFunc()
{
   document.getElementById("search").submit();
   var searchtext=document.getElementById("searchtext").value;
   alert("正在搜索"+searchtext);
}
